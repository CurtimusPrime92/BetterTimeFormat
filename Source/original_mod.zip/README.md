# RW_BetterTimeFormat
Changes the display of the clock in-game.

# Notice
The original code for the DateReadout.DateOnGUI function is taken from RimWorld and is originally written by Tynan. I do not claim any rights over the original parts of this code, except for the changes I have made along the way. The MPL2 license only applies to my code, not the original game code.
